<?

/**
 * Include the sections that make up the home page.
 */
include PUBLIC_THEME . 'sections/head.php';
include PUBLIC_THEME . 'sections/header.php';
include PUBLIC_THEME . 'sections/editions.php';
include PUBLIC_THEME . 'sections/footer.php';
include PUBLIC_THEME . 'sections/foot.php';