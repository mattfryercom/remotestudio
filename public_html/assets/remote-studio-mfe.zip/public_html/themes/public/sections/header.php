		<header>
			<div class="header">
				<a href="<?= REL_PUBLIC_ROOT ?>" class="logo">
					<?= file_get_contents(ASSETS . 'logo.svg') . "\n" ?>
				</a>
				<h1>The Minimal CMS and Framework for Web Developers</h1>
				<p>Remote Studio is a content management system and framework for web developers who need a minimal codebase for building websites and web applications. It is built with <a href="//www.php.net/">PHP</a>.</p>
			</div>
		</header>
