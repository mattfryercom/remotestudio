		<script src="<?= REL_PUBLIC_THEME ?>scripts-min.js?v=<?= THEME_VERSION ?>"></script>
	</body>
</html>
<? ob_flush() ?>