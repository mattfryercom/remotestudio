		<footer>
			<div class="footer">
				<p>Remote Studio is in active development by <a href="//teamremote.uk">Remote</a></p>
				<p>Disclaimer: Remote Studio is free software. It comes without any warranty, to the extent permitted by applicable law. You can redistribute it and/or modify it.</p>
			</div>
		</footer>
