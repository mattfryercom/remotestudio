			<div class="editions">
				<div class="row">
					<h2>Editions</h2>
					<div class="section">
						<h3>Remote Studio</h3>
						<p>The Full Version of Remote Studio including the CMS (Admin Section).</p>
						<a href="">Coming Soon</a>
					</div>
					<div class="section">
						<h3>Remote Studio MFE</h3>
						<p>The Minimal Frontend Edition of Remote Studio, this is as minimal as a Frontend framework gets.</p>
						<a href="<?= REL_ASSETS ?>remote-studio-mfe.zip">Download</a>
					</div>
					<div class="section">
						<h3>Remote Studio FE</h3>
						<p>The Frontend Edition of Remote Studio, including premade frontend objects.</p>
						<a href="">Coming Soon</a>
					</div>
				</div>
			</div>